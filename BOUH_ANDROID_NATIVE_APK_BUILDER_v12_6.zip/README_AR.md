# BOUH GOLD PRO ULTRA v12.6 — Native Android APK Builder

هذه حزمة Android Native كاملة وليست Flutter Demo.

## ماذا تحتوي؟
- تطبيق Android حقيقي WebView Hybrid.
- واجهة عربية باسم بوح التضاريس.
- كلمة مرور: Abuaziza2000
- خرائط Google Satellite / Hybrid / OSM / USGS / NASA.
- تحليل نقاط جيولوجي.
- GPZ 7000.
- تصدير KML/CSV.
- مساعد داخلي + OpenAI عند إضافة المفتاح.
- GitHub Actions يبني APK قابل للتثبيت.

## طريقة البناء
ارفع كل محتويات هذه الحزمة إلى مستودع GitHub، ثم افتح Actions.
بعد نجاح البناء حمل:
BOUH-GOLD-PRO-ULTRA-v12-6-INSTALL-APK